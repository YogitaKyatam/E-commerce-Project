<div class="footer">
            
            <div>
                <strong>Copyright @</strong> Food Ordering System &copy; 2014-2018
            </div>
        </div>